package io.github.shyamkanth.zynance.modal

interface UpdateListener {
    fun shouldUpdate(flag: Boolean)
}